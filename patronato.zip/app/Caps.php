<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class caps extends Model
{
    protected $table = 'caps';

    protected $fillable = [
        'nombre', 'habilitado'
    ];

    protected $attributes = [
        'habilitado' => true,
    ];

    protected $hidden = [
    
    ];

    private $rules = [
        'nombre' => 'required',
        'habilitado' => 'required',
    ];
}
