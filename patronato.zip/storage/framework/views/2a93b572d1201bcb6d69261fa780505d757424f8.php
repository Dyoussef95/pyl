<h5>Consumos</h5>
<button type="button" class="btn btn-primary"
   onclick="location.href='../../situacionsalud/createConsumo/<?php echo e($situacionsalud->id); ?>'">Agregar Nuevo</button>
<table class="table" id="tabla" style="width:auto">
   <thead>
      <tr>
         <th scope="col">Consumo</th>
         <th scope="col">Tipo</th>
         <th scope="col">Recibe Tratamiento</th>
         <th scope="col">Lugar de Tratamiento</th>
         <th scope="col">Tipo de Tratamiento</th>
         <th scope="col"></th>
         <th scope="col"></th>
      </tr>
   </thead>
   <tbody>
      <?php $__currentLoopData = $consumos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consumo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
         <td><?php echo $consumo->objeto_consumo; ?></td>
         <td>
            <?php echo e(isset($consumo->pivot->tipo_consumo_id) ? $tiposConsumo->find($consumo->pivot->tipo_consumo_id)->nombre : ''); ?>

         </td>
         <td>
            <?php if($consumo->pivot->tratamiento==true): ?>
            SI
            <?php else: ?>
            NO
            <?php endif; ?>
         </td>
         <td>
            <?php echo e(isset($consumo->pivot->lugar_tratamiento_consumo_id) ? $centrosConsumo->find($consumo->pivot->lugar_tratamiento_consumo_id)->nombre : ''); ?>

         </td>
         <td>
            <?php echo e(isset($consumo->pivot->tipo_tratamiento_consumos_id) ? $tiposTratamientosConsumo->find($consumo->pivot->tipo_tratamiento_consumos_id)->nombre : ''); ?>

         </td>
         <td>
            <a href="http://localhost/situacionsalud/consumo/<?php echo e($situacionsalud->id); ?>/<?php echo e($consumo->id); ?>/edit"
               class="btn btn-success btn-sm">Editar</a>
         </td>
         <td>
            <form action="http://localhost/situacionsalud/consumo/<?php echo e($situacionsalud->id); ?>/<?php echo e($consumo->id); ?>" method="POST">
               <?php echo method_field('DELETE'); ?>
               <?php echo csrf_field(); ?>
               <div class="form-group">
                  <input type="hidden" name="url" class="form-control" id="" value=<?php echo e(URL::current()); ?>>
               </div>
               <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
            </form>
         </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>
</table><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/situacionsaluds/indexConsumo.blade.php ENDPATH**/ ?>