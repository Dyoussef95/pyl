<?php $__env->startSection('content'); ?>
    
    <form action="/enfermedads" method="POST" role="form">
        <legend>Crear nueva Enfermedad</legend>
    
        <?php echo $__env->make('enfermedads._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
        <button type="submit" class="btn btn-primary">Agregar</button>
    </form>
     
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/enfermedads/create.blade.php ENDPATH**/ ?>