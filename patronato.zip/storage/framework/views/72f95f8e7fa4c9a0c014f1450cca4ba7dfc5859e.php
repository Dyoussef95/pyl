<?php $__env->startSection('title'); ?>
    Editar Trabajo <?php echo e($trabajo->nombre); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <form action="/trabajos/<?php echo e($trabajo->id); ?>" method="POST" role="form">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <legend>Editar trabajo</legend>

        <?php echo $__env->make('trabajos._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>
     
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/trabajos/edit.blade.php ENDPATH**/ ?>