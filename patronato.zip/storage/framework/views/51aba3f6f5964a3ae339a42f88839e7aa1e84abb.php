<?php $__env->startSection('title'); ?>
Editar Situacion de Salud de <?php echo e($situacionsalud->interno->nombre); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form action="/situacionsaluds/<?php echo e($situacionsalud->id); ?>" method="POST" id="form" role="form">
   <?php echo method_field('PUT'); ?>
   <?php echo csrf_field(); ?>
   <legend>Editar Situacion de Salud de <?php echo e($situacionsalud->interno->nombre); ?></legend>

   <?php echo $__env->make('situacionsaluds._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <button type="submit" class="btn btn-primary">Actualizar</button>
</form>

<?php if(isset($situacionsalud)): ?>

   <?php echo $__env->make('situacionsaluds.indexEnfermedad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <br>

   <?php echo $__env->make('situacionsaluds.indexConsumo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/situacionsaluds/edit.blade.php ENDPATH**/ ?>