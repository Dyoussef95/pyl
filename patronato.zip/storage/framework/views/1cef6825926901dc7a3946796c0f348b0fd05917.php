<?php $__env->startSection('title'); ?>
    Editar Situacion Salud Enfermedad
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <form action="/situacionsalud/enfermedad/<?php echo e($situacionSaludEnfermedad->situacion_salud_id); ?>/<?php echo e($situacionSaludEnfermedad->enfermedad_id); ?>" method="POST" id="form" role="form">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <legend>Editar Situacion Salud Enfermedad</legend>

        <?php echo $__env->make('situacionsaluds._formEnfermedad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>
     
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/situacionsaluds/editEnfermedad.blade.php ENDPATH**/ ?>