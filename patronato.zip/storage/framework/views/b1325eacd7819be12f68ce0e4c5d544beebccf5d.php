
   
   
   <a href="../../situacionsaluds/<?php echo e($situacionsalud->id); ?>/edit" class="btn btn-success btn-sm">Editar</a><br> 
   <label for="">Tiene cobertura medica?: </label> 
       
   <span class="label label-success">
   <?php if($situacionsalud->cobertura_medica==true): ?>
      SI
   <?php else: ?>
      NO
   <?php endif; ?>

   <h5>Enfermedades</h5>
   <table class="table" id="tabla" style="width:auto">
      <thead>
         <tr>
            <th scope="col">Enfermedad</th>
            <th scope="col">Recibe Tratamiento</th>
            <th scope="col">Lugar de Tratamiento</th>
         </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $situacionsaludenfermedads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $situacionsaludenfermedad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php if($situacionsaludenfermedad->situacion_salud->id==$situacionsalud->id): ?>
            <tr>
               <td><?php echo $situacionsaludenfermedad->enfermedad->nombre; ?></td>
               <td>
                  <?php if($situacionsaludenfermedad->tratamiento==true): ?>
                     SI
                  <?php else: ?>
                     NO
                  <?php endif; ?>
               </td>
               <td> <?php echo e(isset($situacionsaludenfermedad->lugar_tratamiento) ? $situacionsaludenfermedad->lugar_tratamiento->nombre : ''); ?></td>
            </tr>
            <?php endif; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
   </table>
             
  

<?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/situacionsaluds/index.blade.php ENDPATH**/ ?>