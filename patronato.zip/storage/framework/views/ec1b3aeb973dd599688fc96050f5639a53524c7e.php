<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('parametersContent'); ?>

   <h1 id="demo">Tipos de Motivos de Ingreso al Programa</h1>
   
   <button type="button" class="btn btn-info" onclick="location.href='tipomotivoingresoprogramas/create'">Agregar Nuevo</button>
   <br><br>
   <div class="table-responsive-sm">
   <table class="table table-striped" id="dataTable" style="width:auto">
      <thead class="thead-dark">
         <tr>
            <th scope="col">Nombre</th>
            <th scope="col"></th>
            <th scope="col"></th>
         </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $tipomotivoingresoprogramas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipomotivoingresoprograma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <td><?php echo $tipomotivoingresoprograma -> nombre; ?></td>
               <td>
                  <a href="tipomotivoingresoprogramas/<?php echo e($tipomotivoingresoprograma->id); ?>/edit" class="btn btn-success btn-sm">Editar</a>
               </td>
               <td>
                  <form action="/tipomotivoingresoprogramas/<?php echo e($tipomotivoingresoprograma->id); ?>" method="POST">
                     <?php echo method_field('DELETE'); ?>
                     <?php echo csrf_field(); ?>
                     <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                  </form>                     
               </td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
   </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('parameters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/tipomotivoingresoprogramas/index.blade.php ENDPATH**/ ?>