<?php echo csrf_field(); ?>

<div class="form-group">
    <label for="">Enfermedad</label>
    <select name="enfermedad_id" form="form" class="select2" style="width:400px;">
        <?php $__currentLoopData = $listaEnfermedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listaEnfermedad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value=<?php echo e($listaEnfermedad->id); ?> <?php if(isset($situacionSaludEnfermedad)): ?>
            <?php echo e($listaEnfermedad->id==$situacionSaludEnfermedad->enfermedad_id ? 'selected' : ''); ?> <?php endif; ?>>
            <?php echo e($listaEnfermedad->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group" onclick="ocultarLugar();">
    <label for="">Recibe tratamiento?</label>
    <br>
    <input type="radio" name="tratamiento" value="false" checked> No<br>
    <input id="radioTrue" type="radio" name="tratamiento" value="true" <?php if(isset($situacionSaludEnfermedad)): ?>
        <?php echo e($situacionSaludEnfermedad->tratamiento==true ? 'checked' : ''); ?> <?php endif; ?>> Si<br>

</div>

<div class="form-group" id="form_lugar_tratamiento" style=
<?php if(isset($situacionSaludEnfermedad)): ?> 
    <?php echo e($situacionSaludEnfermedad->tratamiento==false ? "display:none" : "display:block"); ?>

<?php else: ?>
   <?php echo e("display:none"); ?> 
<?php endif; ?>
>
    <label for="">Lugar de Tratamiento</label>
    <select name="lugar_tratamiento_id" form="form" class="select2" style="width:400px;">
        <?php $__currentLoopData = $centrosSalud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centroSalud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value=<?php echo e($centroSalud->id); ?> <?php if(isset($situacionSaludEnfermedad)): ?>
            <?php echo e($centroSalud->id == $situacionSaludEnfermedad->lugar_tratamiento_id ? 'selected' : ''); ?> <?php endif; ?>>
            <?php echo e($centroSalud->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <input type="hidden" name="url" class="form-control" id="" value=<?php echo e(URL::previous()); ?>>
</div>

<script>
    function ocultarLugar(){
        var x = document.getElementById("form_lugar_tratamiento");
        var y = document.getElementById("radioTrue");
        if (y.checked == true) {
            x.style.display = "block";
        } else {
            x.style.display = "none";
        }
    }
</script><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/situacionsaluds/_formEnfermedad.blade.php ENDPATH**/ ?>