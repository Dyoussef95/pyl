<?php $__env->startSection('title'); ?>
    Editar nacionalidad <?php echo e($nacionalidad->nombre); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <form action="/nacionalidades/<?php echo e($nacionalidad->id); ?>" method="POST" role="form">
        <?php echo method_field('PUT'); ?>
        <legend>Editar nacionalidad</legend>

        <?php echo $__env->make('nacionalidades._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>
     
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/nacionalidades/edit.blade.php ENDPATH**/ ?>