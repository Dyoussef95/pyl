
    <?php echo csrf_field(); ?>
    <div class="form-group">
            <input type="hidden" name="situacion_salud_id" class="form-control" id="" value=<?php echo e(isset($situacionsaludenfermedad) ? $situacionsaludenfermedad->situacion_salud_id : $situacionsalud->id); ?>>
    </div>
    

    <div class="form-group">
            <label for="">Enfermedad</label>
            <select name="enfermedad_id" form="form" class="select2" style="width:400px;">
                <?php if(isset($enfermedads)): ?>
                    <?php $__currentLoopData = $enfermedads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enfermedad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($enfermedad->id); ?>><?php echo e($enfermedad->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
    </div>

    <div class="form-group">
            <label for="">Recibe tratamiento?</label>
            <br>
            <input type="radio" name="tratamiento" value="true" 
            <?php if(isset($situacionsaludenfermedad)): ?>
                <?php echo e($situacionsaludenfermedad->tratamiento==true ? 'checked' : ''); ?>

            
            <?php endif; ?>
            > Si<br>
            <input type="radio" name="tratamiento" value="false"
            <?php if(isset($situacionsaludenfermedad)): ?>
                <?php echo e($situacionsaludenfermedad->tratamiento==false ? 'checked' : ''); ?>

            <?php else: ?>
                checked
            <?php endif; ?>
            > No<br>  
        </div>

        <div class="form-group">
                <label for="">Lugar de Tratamiento</label>
                <select name="lugar_tratamiento_id" form="form" class="select2" style="width:400px;">
                    <?php if(isset($centrosaluds)): ?>
                        <?php $__currentLoopData = $centrosaluds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centrosalud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=<?php echo e($centrosalud->id); ?>><?php echo e($centrosalud->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
        </div>

        <div class="form-group">
                <input type="hidden" name="url" class="form-control" id="" value=<?php echo e(URL::previous()); ?>>
        </div>




<?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/situacionsaludenfermedads/_form.blade.php ENDPATH**/ ?>