
<?php
    session_start();
?>

<div class="form-group">
    <label for="">Apellidos</label>
<input required type="text" name="apellido" value="<?php echo e(isset($interno) ? $interno->apellido : ''); ?>" class="form-control" id="" placeholder="Ingrese los apellidos">
</div>

<div class="form-group">
    <label for="">Nombres</label>
<input required type="text" name="nombre" value="<?php echo e(isset($interno) ? $interno->nombre : ''); ?>" class="form-control" id="" placeholder="Ingrese los nombres">
</div>

<div class="form-group">
    <label for="">Legajo</label>
<input required type="number" name="legajo" value="<?php echo e(isset($interno) ? $interno->legajo : ''); ?>" class="form-control" id="" placeholder="Ingrese el legajo">
</div>

<div class="form-group">
    <label for="">Fecha de Nacimiento</label>
<input type="date" name="fecha_nacimiento" value="<?php echo e(isset($interno) ? $interno->fecha_nacimiento : ''); ?>" class="form-control" id="" placeholder="DD/MM/AAAA">
</div>

<div class="form-group">
    <label for="">Tipo de documento</label>
    <select name="tipos_documento_id" form="form" class="select2" style="width:400px;">       
        <?php if(isset($tipodocumentos)): ?>
            <?php $__currentLoopData = $tipodocumentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipodocumento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($tipodocumento->id); ?>><?php echo e($tipodocumento->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
    
</div>


<div class="form-group">
    <label for="">Numero de documento</label>
<input type="text" name="numero_documento" value="<?php echo e(isset($interno) ? $interno->numero_documento : ''); ?>" class="form-control" id="" placeholder="Ingrese el documento">
</div>

<div class="form-group">
    <label for="">Nacionalidad</label>
    <select name="nacionalidad_id" form="form" class="select2" style="width:400px;">            
        <?php $__currentLoopData = $nacionalidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nacionalidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <option value=<?php echo e($nacionalidad->id); ?>><?php echo e($nacionalidad->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
    </select>
</div>

<div class="form-group">
    <label for="">Localidad</label>
    <select name="localidad_id" form="form" class="select2" style="width:400px;">            
        <?php $__currentLoopData = $localidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <option value=<?php echo e($localidad->id); ?>><?php echo e($localidad->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
    </select>
</div>

<div class="form-group">
    <label for="">Domicilio Declarado</label>
<input type="text" name="domicilioDeclarado" value="<?php echo e(isset($interno) ? $interno->domicilioDeclarado : ''); ?>" class="form-control" id="" placeholder="Ingrese el documento">
</div>

<div class="form-group">
        <label for="">Juzgado</label>
        <select name="juzgado_tipos_id" form="form" class="select2" style="width:400px;">            
                <?php $__currentLoopData = $juzgadotipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juzgadotipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($juzgadotipo->id); ?>><?php echo e($juzgadotipo->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
        </select>
</div>

<div class="form-group">
    <label for="">Estado civil</label>
    <select name="estado_civil_id" form="form" class="select2" style="width:400px;">
        <?php if(isset($estadociviles)): ?>
            <?php $__currentLoopData = $estadociviles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estadocivil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($estadocivil->id); ?>><?php echo e($estadocivil->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<div class="form-group">
    <label for="">Situacion laboral</label>
    <select name="situaciones_laborales_id" form="form" class="select2" style="width:400px;">
        <?php if(isset($situacioneslaborales)): ?>
            <?php $__currentLoopData = $situacioneslaborales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $situacionlaboral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($situacionlaboral->id); ?>><?php echo e($situacionlaboral->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<div class="form-group">
    <label for="">Nivel de estudio</label>
    <select name="nivel_estudio_id" form="form" class="select2" style="width:400px;">
        <?php if(isset($nivelestudios)): ?>
            <?php $__currentLoopData = $nivelestudios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nivelestudio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($nivelestudio->id); ?>><?php echo e($nivelestudio->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<div class="form-group">
        <label for="">Genero</label>
        <select name="sexo_id" form="form" class="select2" style="width:400px;">            
                <?php $__currentLoopData = $sexos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sexo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($sexo->id); ?>><?php echo e($sexo->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
        </select>
</div>

<div class="form-group">
        <label for="">Trabajo</label>
        <select name="trabajo_id" form="form" class="select2" style="width:400px;">            
                <?php $__currentLoopData = $trabajos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($trabajo->id); ?>><?php echo e($trabajo->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
        </select>
        <i class="fas fa-plus-circle" onclick="location.href='../trabajos/create'" style="cursor: pointer;"></i>
</div>

<div class="form-group">
        <label for="">Observaciones</label>
    <input type="text" name="observaciones" value="<?php echo e(isset($interno) ? $interno->observaciones : ''); ?>" class="form-control" id="" placeholder="Ingrese texto">
</div>

<div class="form-group">
    <input type="hidden" name="url" class="form-control" id="" value=<?php echo e(URL::previous()); ?>>
</div>
<?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/internos/_form.blade.php ENDPATH**/ ?>