<?php echo csrf_field(); ?>

<div class="form-group">
    <label for="">Nombre</label>
<input type="text" name="nombre" value="<?php echo e(isset($grupoFamiliar) ? $grupoFamiliar->nombre : ''); ?>" class="form-control" id="" placeholder="Ingrese los nombres">
</div>

<div class="form-group">
    <label for="">Apellido</label>
<input type="text" name="apellido" value="<?php echo e(isset($grupoFamiliar) ? $grupoFamiliar->apellido : ''); ?>" class="form-control" id="" placeholder="Ingrese los apellidos">
</div>

<div class="form-group">
    <label for="">Parentezco: </label>
    <select name="parentezco_id" form="form" class="select2" style="width:400px;">
        <?php if(isset($parentezcos)): ?>
            <?php $__currentLoopData = $parentezcos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentezco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($parentezco->id); ?>

                    <?php if(isset($grupoFamiliar)): ?>
                        <?php if($grupoFamiliar->parentezco_id==$parentezco->id): ?>
                            selected
                        <?php endif; ?>                        
                    <?php endif; ?>
                ><?php echo e($parentezco->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<div class="form-group">
    <label for="">Fecha de Nacimiento</label>
<input type="date" name="fecha_nacimiento" value="<?php echo e(isset($grupoFamiliar) ? $grupoFamiliar->fecha_nacimiento : ''); ?>" class="form-control" id="" placeholder="DD/MM/AAAA">
</div>

<div class="form-group">
    <label for="">Tipo de documento: </label>
    <select name="tipo_documento_id" form="form" class="select2" style="width:400px;">
        <?php if(isset($tiposDocumentos)): ?>
            <?php $__currentLoopData = $tiposDocumentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoDocumento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($tipoDocumento->id); ?>

                    <?php if(isset($grupoFamiliar)): ?>
                        <?php if($grupoFamiliar->tipo_documento_id==$tipoDocumento->id): ?>
                            selected  
                        <?php endif; ?>                        
                    <?php endif; ?>
                ><?php echo e($tipoDocumento->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<div class="form-group">
    <label for="">N° de Documento</label>
<input type="text" name="numero_documento" value="<?php echo e(isset($grupoFamiliar) ? $grupoFamiliar->numero_documento : ''); ?>" class="form-control" id="" placeholder="Ingrese el documento">
</div>

<div class="form-group">
    <label for="">Genero: </label>
    <select name="sexo_id" form="form" class="select2" style="width:400px;">
        <?php if(isset($sexos)): ?>
            <?php $__currentLoopData = $sexos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sexo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($sexo->id); ?>

                    <?php if(isset($grupoFamiliar)): ?>
                        <?php if($grupoFamiliar->sexo_id==$sexo->id): ?>
                            selected
                        <?php endif; ?>                        
                    <?php endif; ?>
                ><?php echo e($sexo->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<div class="form-group">
    <label for="">Domicilio: </label>
<input type="text" name="domicilio" value="<?php echo e(isset($grupoFamiliar) ? $grupoFamiliar->domicilio : ''); ?>" class="form-control" id="" placeholder="Ingrese el domicilio">
</div>

<div class="form-group">
    <label for="">Nivel de estudio: </label>
    <select name="nivel_estudio_id" form="form" class="select2" style="width:400px;">
        <?php if(isset($nivelesEstudio)): ?>
            <?php $__currentLoopData = $nivelesEstudio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nivelEstudio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($nivelEstudio->id); ?>

                    <?php if(isset($grupoFamiliar)): ?>
                        <?php if($grupoFamiliar->nivel_estudio_id==$nivelEstudio->id): ?>
                            selected  
                        <?php endif; ?>                        
                    <?php endif; ?>
                ><?php echo e($nivelEstudio->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<div class="form-group">
    <label for="">Estado civil: </label>
    <select name="estado_civil_id" form="form" class="select2" style="width:400px;">
        <?php if(isset($estadosCiviles)): ?>
            <?php $__currentLoopData = $estadosCiviles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estadoCivil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($estadoCivil->id); ?>

                    <?php if(isset($grupoFamiliar)): ?>
                        <?php if($grupoFamiliar->estado_civil_id==$estadoCivil->id): ?>
                           selected 
                        <?php endif; ?>
                        
                    <?php endif; ?>
                ><?php echo e($estadoCivil->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<div class="form-group">
    <label for="">Situacion laboral: </label>
    <select name="situacion_laboral_id" form="form" class="select2" style="width:400px;">
        <?php if(isset($situacionesLaborales)): ?>
            <?php $__currentLoopData = $situacionesLaborales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $situacionLaboral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($situacionLaboral->id); ?>

                    <?php if(isset($grupoFamiliar)): ?>
                        <?php if($grupoFamiliar->situacion_laboral_id==$situacionLaboral->id): ?>
                          selected  
                        <?php endif; ?>                        
                    <?php endif; ?>
                ><?php echo e($situacionLaboral->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<div class="form-group">
    <label for="">Oficio / Profesion: </label>
    <select name="trabajo_id" form="form" class="select2" style="width:400px;">
        <?php if(isset($trabajos)): ?>
            <?php $__currentLoopData = $trabajos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($trabajo->id); ?>

                    <?php if(isset($grupoFamiliar)): ?>
                        <?php if($grupoFamiliar->trabajo_id==$trabajo->id): ?>
                           selected 
                        <?php endif; ?>                        
                    <?php endif; ?>
                ><?php echo e($trabajo->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<div class="form-group">
    <label for="">Observaciones: </label><br />
    <textarea style="width: 100mm; height:40mm" form="form"  name="observacion" placeholder="Ingrese una observacion">
<?php echo e(isset($grupoFamiliar) ? $grupoFamiliar->observacion : ''); ?>

    </textarea>
</div>

<div class="form-group">
    <input type="hidden" name="url" class="form-control" id="" value="<?php echo e(URL::previous()); ?>">
</div><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/GruposFamiliares/_form.blade.php ENDPATH**/ ?>