<div class="form-group">
    <label for="">Nombres:</label>
<input required type="text" name="nombre" value="<?php echo e(isset($historia)?$historia->interno->nombre:''); ?>" class="form-control" id="" placeholder="Ingrese los nombres">
</div>
<?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


<div class="form-group">
    <label for="">Apellidos:</label>
<input required type="text" name="apellido" value="<?php echo e(isset($historia)?$historia->interno->apellido:''); ?>" class="form-control" id="" placeholder="Ingrese los apellidos">
</div>

<div class="form-group">
    <label for="">Ingrese la fecha de inicio del tutelado:</label>
<input required type="date" name="fecha_inicio" value="<?php echo e(isset($historia) ? $historia->fecha_inicio : $hoy); ?>" class="form-control" id="fecha_inicio">
</div>

<div class="form-group">
    <label for="">Seleccione el motivo de ingreso:</label>
    <select name="motivo_ingreso_programa_id" form="form" class="select2" style="width: 100%">
        <?php if(isset($motivoingresoprogramas)): ?>
            <?php $__currentLoopData = $motivoingresoprogramas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motivoingresoprograma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($motivoingresoprograma->id); ?>

                    <?php if(isset($historia)): ?>
                        <?php echo e($historia->motivo_ingreso->id==$motivoingresoprograma->id ? 'selected' : ''); ?>

                    <?php endif; ?>
                ><?php echo e($motivoingresoprograma->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>


<div class="form-group">
    <label for="">Seleccione la procedencia:</label>
    <select name="juzgado_especifico_id" form="form" class="select2" style="width: 100%">
        <?php if(isset($juzgadoespecificos)): ?>
            <?php $__currentLoopData = $juzgadoespecificos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juzgadoespecifico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($juzgadoespecifico->id); ?>

                    <?php if(isset($historia)): ?>
                        <?php echo e($historia->juzgadoEspecifico->id==$juzgadoespecifico->id ? 'selected' : ''); ?>

                    <?php endif; ?>
                ><?php echo e($juzgadoespecifico->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<div class="form-group">
    <label for="">Seleccione el regimen:</label>
    <select name="regimen_id" form="form" class="select2" style="width: 100%">
        <?php if(isset($regimenes)): ?>
            <?php $__currentLoopData = $regimenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regimen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($regimen->id); ?>

                    <?php if(isset($historia)): ?>
                        <?php echo e($historia->regimen->id==$regimen->id ? 'selected' : ''); ?>

                    <?php endif; ?>
                ><?php echo e($regimen->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<div class="form-group">
    <label for="">Seleccione el profesional:</label>
    <select name="empleado_id" form="form" class="select2" style="width: 100%">
        <?php if(isset($empleados)): ?>
            <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($empleado->id); ?>

                    <?php if(isset($historia)): ?>
                        <?php echo e($historia->empleado()->first()->id==$empleado->id ? 'selected' : ''); ?>

                    <?php endif; ?>
                ><?php echo e($empleado->apellido); ?>&nbsp<?php echo e($empleado->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<div class="form-group">
    <input type="hidden" name="legajo" class="form-control" id="" value="<?php echo e(isset($historia) ? $historia->interno->legajo : $nuevoLegajo); ?>">
</div>

<div class="form-group">
    <input type="hidden" name="url" class="form-control" id="" value=<?php echo e(URL::previous()); ?>>
</div>

<?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/mesaentrada/_form.blade.php ENDPATH**/ ?>