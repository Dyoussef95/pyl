<?php $__env->startSection('content'); ?>
<nav>
   <div class="nav nav-tabs" id="nav-tab" role="tablist">
      <a class="nav-item nav-link active" id="nav-datos-personales-tab" data-toggle="tab" href="#datos-personales"
         role="tab" aria-controls="datos-personales" aria-selected="true">Datos Personales</a>
      <a class="nav-item nav-link" id="nav-datos-legales-tab" data-toggle="tab" href="#datos-legales" role="tab"
         aria-controls="datos-legales" aria-selected="false">Datos Legales</a>
      <a class="nav-item nav-link" id="nav-datos-salud-tab" data-toggle="tab" href="#datos-salud" role="tab"
         aria-controls="datos-salud" aria-selected="false">Datos de Salud</a>
      <a class="nav-item nav-link" id="nav-grupo-familiar-tab" data-toggle="tab" href="#grupo-familiar" role="tab"
         aria-controls="grupo-familiar" aria-selected="false">Grupo Familiar</a>
   </div>
</nav>

<div class="tab-content" id="nav-tabContent">
   
   <div class="tab-pane fade show active" id="datos-personales" role="tabpanel" aria-labelledby="ndatos-personales-tab">
      Nombre: <?php echo $interno->nombre; ?> <br>
      Apellido: <?php echo $interno->apellido; ?> <br>
      Genero: <?php echo e(isset($interno->sexo) ? $interno->sexo->nombre : 'SIN INFORMACION'); ?> <br>
      DNI: <?php echo isset($interno->numero_documento) ? $interno->numero_documento : 'SIN INFORMACION'; ?> <br>
      Domicilio Declarado: <?php echo e(isset($interno->domicilioDeclarado) ? $interno->domicilioDeclarado : 'SIN INFORMACION'); ?>

      <br>
      Nacionalidad: <?php echo isset($interno->nacionalidad) ? $interno->nacionalidad->nombre : 'SIN INFORMACION'; ?> <br>
      Localidad: <?php echo isset($interno->localidad) ? $interno->localidad->nombre : 'SIN INFORMACION'; ?> <br>
      Estado Civil: <?php echo e(isset($interno->estado_civil) ? $interno->estado_civil->nombre : 'SIN INFORMACION'); ?> <br>
      Fecha de Nacimiento: <?php echo e(isset($interno->fecha_nacimiento) ? $interno->fecha_nacimiento : 'SIN INFORMACION'); ?> <br>
      Edad: <?php echo e(isset($interno->fecha_nacimiento) ? $edad : 'SIN INFORMACION'); ?> <br>
      Nivel de Instruccion: <?php echo e(isset($interno->nivel_estudio) ? $interno->nivel_estudio->nombre : 'SIN INFORMACION'); ?>

      <br>
      Situacion Laboral:
      <?php echo e(isset($interno->situacion_laboral) ? $interno->situacion_laboral->nombre : 'SIN INFORMACION'); ?> <br>
      Trabajo: <?php echo e(isset($interno->trabajo) ? $interno->trabajo->nombre : 'SIN INFORMACION'); ?> <br>
   </div>

   <div class="tab-pane fade" id="datos-legales" role="tabpanel" aria-labelledby="datos-legales-tab">
      <?php if($historia==null): ?>
         No hay datos registrados...
         <br>
         <a href="../historias/create/<?php echo e($interno->id); ?>" class="btn btn-success btn-sm m-0">Ingresar Datos</a>
      <?php else: ?>
         Legajo: <?php echo $interno->legajo; ?> <br>
         Area: <?php echo e($historia->regimen->area->nombre); ?> <br>
         Regimen: <?php echo e($historia->regimen->nombre); ?> <br>
         Fecha de Ingreso: <?php echo e($historia->fecha_inicio); ?> <br>
         Tipo Delito:
         <?php echo e(isset($historia->delito_especifico->tipo_delito->nombre) ? $historia->delito_especifico->tipo_delito->nombre : 'SIN INFORMACION'); ?>

         <br>
         Delito Especifico:
         <?php echo e(isset($historia->delito_especifico->nombre) ? $historia->delito_especifico->nombre : 'SIN INFORMACION'); ?> <br>
         Motivo de Ingreso al Programa: <?php echo e($historia->motivo_ingreso->nombre); ?> <br>
         Situacion Procesal:
         <?php echo e(isset($historia->situacion_procesal->nombre) ? $historia->situacion_procesal->nombre : 'SIN INFORMACION'); ?><br>
         Frecuencia de Control:
         <?php echo e(isset($historia->frecuencia->nombre) ? $historia->frecuencia->nombre : 'SIN INFORMACION'); ?><br>
         <?php if($historia->empleado()->first()->id==Auth::user()->empleado->id): ?>
            <a href="../historias/<?php echo e($historia->id); ?>/edit" class="btn btn-success btn-sm">Editar</a>
         <?php endif; ?>
      <?php endif; ?>
   </div>

   <div class="tab-pane fade" id="datos-salud" role="tabpanel" aria-labelledby="datos-salud-tab">
      <?php if(isset($interno->situacion_salud->id)): ?>
      <?php echo $__env->make('situacionsaluds.index',['situacionsalud' => $interno->situacion_salud], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>

      <?php if(empty($interno->situacion_salud->id)): ?>
      No hay datos registrados...
      <br>
      <a href="../situacionsaluds/create/<?php echo e($interno->id); ?>" class="btn btn-primary btn-sm m-0">Ingresar Datos</a>
      <?php endif; ?>
   </div>

   <div class="tab-pane fade" id="grupo-familiar" role="tabpanel" aria-labelledby="grupo-familiar-tab">
         <?php echo $__env->make('GruposFamiliares._index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/internos/show.blade.php ENDPATH**/ ?>