<?php $__env->startSection('content'); ?>
    
    <form action="/juzgadosespecificos" method="POST" role="form" id="form">
        <?php echo csrf_field(); ?>
        <legend>Crear nuevo Juzgado Especifico</legend>
    
        <?php echo $__env->make('juzgadosespecificos._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <button type="submit" class="btn btn-primary">Agregar</button>
    </form>
     
<?php $__env->stopSection(); ?> 


<?php echo $__env->make('Index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/juzgadosespecificos/create.blade.php ENDPATH**/ ?>