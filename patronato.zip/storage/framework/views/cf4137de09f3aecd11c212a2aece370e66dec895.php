<?php echo csrf_field(); ?>
<div class="form-group needs-validation">
    <label for="">Tiene cobertura medica?</label>
    <br>
    <input type="radio" name="cobertura_medica" value="true"
    <?php if(isset($situacionsalud)): ?>
        <?php echo e($situacionsalud->cobertura_medica==true ? 'checked' : ''); ?>

    <?php endif; ?>
    > Si<br>
    <input type="radio" name="cobertura_medica" value="false"
    <?php if(isset($situacionsalud)): ?>
        <?php echo e($situacionsalud->cobertura_medica==false ? 'checked' : ''); ?>

    <?php endif; ?>
    > No<br>  
</div>

<div class="form-group">
    <input type="hidden" name="interno_id" class="form-control" id="" value="<?php echo e(isset($situacionsalud) ? $situacionsalud->interno->id : $interno->id); ?>">
</div>

<div class="form-group">
        <input type="hidden" name="url" class="form-control" id="" value=<?php echo e(URL::previous()); ?>>
</div>


<?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/situacionsaluds/_form.blade.php ENDPATH**/ ?>