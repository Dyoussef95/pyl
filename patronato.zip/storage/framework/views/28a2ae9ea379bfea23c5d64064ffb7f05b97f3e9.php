<?php $__env->startSection('title'); ?>
    Editar Situacion Salud Consumo
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <form action="/situacionsalud/consumo/<?php echo e($situacionSaludConsumo->situacion_salud_id); ?>/<?php echo e($situacionSaludConsumo->consumo_id); ?>" method="POST" id="form" role="form">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <legend>Editar Situacion Salud Consumo</legend>

        <?php echo $__env->make('situacionsaluds._formConsumo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>
     
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/situacionsaluds/editConsumo.blade.php ENDPATH**/ ?>