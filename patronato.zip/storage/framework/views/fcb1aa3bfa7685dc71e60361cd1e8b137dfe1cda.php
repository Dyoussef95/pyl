<?php $__env->startSection('content'); ?>

   <?php echo $__env->make('GruposFamiliares._index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?> 


<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/GruposFamiliares/index.blade.php ENDPATH**/ ?>