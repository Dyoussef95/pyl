<div class="form-group">
    <label for="">Fecha Inicio</label>
<input required type="date" name="fechaInicio" value="<?php echo e(isset($historia) ? $historia->fecha_inicio : ''); ?>" style="width:400px;" class="form-control" id="" placeholder="dd/mm/aaaa">
</div>

<div class="form-group">
<label for="">Seleccione el regimen:</label><br>
    <select name="regimen_id" form="form" class="select2" style="width:400px;">
        <?php $__currentLoopData = $regimenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regimen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value=<?php echo e($regimen->id); ?>

                <?php if(isset($historia)): ?>
                    <?php echo e($historia->regimen->id==$regimen->id ? 'selected' : ''); ?>

                <?php endif; ?>
            >
            <?php echo e($regimen->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
<label for="">Seleccione el delito:</label><br>
    <select name="delito_especifico_id" form="form" class="select2" style="width:400px;">
        <?php $__currentLoopData = $delitoespecificos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delitoespecifico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value=<?php echo e($delitoespecifico->id); ?>

                <?php if(isset($historia)): ?>
                    <?php echo e($historia->delito_especifico->id==$delitoespecifico->id ? 'selected' : ''); ?>

                <?php endif; ?>
            >
            <?php echo e($delitoespecifico->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
<label for="">Seleccione la situacion procesal:</label><br>
    <select name="situacion_procesal_id" form="form" class="select2" style="width:400px;">
        <?php $__currentLoopData = $situacionprocesales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $situacionprocesal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value=<?php echo e($situacionprocesal->id); ?>

                <?php if(isset($historia)): ?>
                    <?php echo e($historia->situacion_procesal->id==$situacionprocesal->id ? 'selected' : ''); ?>

                <?php endif; ?>
            >
            <?php echo e($situacionprocesal->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
<label for="">Seleccione el motivo de ingreso al programa:</label><br>
    <select name="motivos_de_ingreso_programa_id" form="form" class="select2" style="width:400px;">
        <?php $__currentLoopData = $motivosdeingresoalprograma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motivodeingresoalprograma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value=<?php echo e($motivodeingresoalprograma->id); ?>

                <?php if(isset($historia)): ?>
                    <?php echo e($historia->motivo_ingreso->id==$motivodeingresoalprograma->id ? 'selected' : ''); ?>

                <?php endif; ?>
            >
            <?php echo e($motivodeingresoalprograma->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
<label for="">Seleccione la frecuencia de control:</label><br>
    <select name="frecuencia_id" form="form" class="select2" style="width:400px;">
        <?php $__currentLoopData = $frecuenciacontroles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frecuenciacontrol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value=<?php echo e($frecuenciacontrol->id); ?>

                <?php if(isset($historia->frecuencia->id)): ?>
                    <?php echo e($historia->frecuencia->id==$frecuenciacontrol->id ? 'selected' : ''); ?>

                <?php endif; ?>
            >
            <?php echo e($frecuenciacontrol->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
<label for="">Seleccione la procedencia:</label><br>
    <select name="juzgado_especifico_id" form="form" class="select2" style="width:400px;">
        <?php $__currentLoopData = $juzgadoespecificos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juzgadoespecifico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value=<?php echo e($juzgadoespecifico->id); ?>

                <?php if(isset($historia)): ?>
                    <?php echo e($historia->juzgadoespecifico->id==$juzgadoespecifico->id ? 'selected' : ''); ?>

                <?php endif; ?>
            >
            <?php echo e($juzgadoespecifico->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
        <input type="hidden" name="url" class="form-control" id="" value=<?php echo e(URL::previous()); ?>>
</div><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/historias/_form.blade.php ENDPATH**/ ?>