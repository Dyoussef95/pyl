<?php $__env->startSection('content'); ?>
    
    <div class="card-header"><legend>Crear nuevo Usuario</legend></div>
    <div class="card-body">
        <form action="/usuarios" method="POST" role="form">          
        
            <?php echo $__env->make('usuarios._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="form-group row mb-0">
                <div class="col-md-6 offset-md-4">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Crear')); ?>

                    </button>
                </div>
            </div>
        </form>
    </div>
     
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/usuarios/create.blade.php ENDPATH**/ ?>