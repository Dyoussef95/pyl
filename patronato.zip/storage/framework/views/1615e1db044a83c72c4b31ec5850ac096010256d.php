<?php $__env->startSection('parametersContent'); ?>
    
   <h1>Estados Civiles</h1>

   <button type="button" class="btn btn-info" onclick="location.href='estadosciviles/create'">Agregar Nuevo</button>
   <br><br>
   <div class="table-responsive-sm">
   <table class="table table-striped" id="tabla" style="width:auto">
      <thead class="thead-dark">
         <tr>
            <th scope="col">Nombre</th>
            <th scope="col"></th>
            <th scope="col"></th>
         </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $estadosciviles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estadocivil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <td><?php echo $estadocivil -> nombre; ?></td>
               <td>
                  <a href="estadosciviles/<?php echo e($estadocivil->id); ?>/edit" class="btn btn-success btn-sm">Editar</a>
               </td>
               <td>
                  <form action="/estadosciviles/<?php echo e($estadocivil->id); ?>" method="POST">
                     <?php echo method_field('DELETE'); ?>
                     <?php echo csrf_field(); ?>
                     <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                  </form>                     
               </td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
   </table>

   <br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('parameters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/estadosciviles/index.blade.php ENDPATH**/ ?>