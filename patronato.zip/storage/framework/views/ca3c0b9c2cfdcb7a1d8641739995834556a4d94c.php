<?php $__env->startSection('content'); ?>
    
    <form action="/situacionsaluds" method="POST" role="form" id="form">
    <legend>Crear nueva Situacion de Salud de <?php echo e($interno->apellido); ?> <?php echo e($interno->nombre); ?></legend>
    
        <?php echo $__env->make('situacionsaluds._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <button type="submit" class="btn btn-primary">Agregar</button>
    </form>
     
<?php $__env->stopSection(); ?> 


<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/situacionsaluds/create.blade.php ENDPATH**/ ?>