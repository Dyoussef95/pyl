<h5>Enfermedades</h5>
<button type="button" class="btn btn-primary"
   onclick="location.href='../../situacionsalud/createEnfermedad/<?php echo e($situacionsalud->id); ?>'">Agregar Nuevo</button>
<table class="table" id="tabla" style="width:auto">
   <thead>
      <tr>
         <th scope="col">Enfermedad</th>
         <th scope="col">Recibe Tratamiento</th>
         <th scope="col">Lugar de Tratamiento</th>
         <th scope="col"></th>
         <th scope="col"></th>
      </tr>
   </thead>
   <tbody>
      <?php $__currentLoopData = $enfermedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enfermedad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
         <td><?php echo $enfermedad->nombre; ?></td>
         <td>
            <?php if($enfermedad->pivot->tratamiento==true): ?>
            SI
            <?php else: ?>
            NO
            <?php endif; ?>
         </td>
         <td>
            <?php echo e(isset($enfermedad->pivot->lugar_tratamiento_id) ? $centrosSalud->find($enfermedad->pivot->lugar_tratamiento_id)->nombre : ''); ?>

         </td>
         <td>
            <a href="http://localhost/situacionsalud/<?php echo e($situacionsalud->id); ?>/<?php echo e($enfermedad->id); ?>/edit"
               class="btn btn-success btn-sm">Editar</a>
         </td>
         <td>
            <form action="http://localhost/situacionsalud/<?php echo e($situacionsalud->id); ?>/<?php echo e($enfermedad->id); ?>" method="POST">
               <?php echo method_field('DELETE'); ?>
               <?php echo csrf_field(); ?>
               <div class="form-group">
                  <input type="hidden" name="url" class="form-control" id="" value=<?php echo e(URL::current()); ?>>
               </div>
               <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
            </form>
         </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>
</table><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/situacionsaluds/showEnfermedad.blade.php ENDPATH**/ ?>