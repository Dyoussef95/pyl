<?php $__env->startSection('parametersContent'); ?>
    
<button type="button" class="btn btn-info" onclick="location.href='motivofinsupervisions/create'">Agregar Nuevo</button>
<br><br>
<div class="table-responsive-sm">
<table class="table table-striped" id="tabla" style="width:auto">
   <thead class="thead-dark">
         <tr>
            <th scope="col">Nombre</th>
            <th scope="col"></th>
            <th scope="col"></th>
         </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $motivofinsupervisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motivofinsupervision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <td><?php echo $motivofinsupervision->nombre; ?></td>
               <td>
                  <a href="motivofinsupervisions/<?php echo e($motivofinsupervision->id); ?>/edit" class="btn btn-success btn-sm">Editar</a>
               </td>
               <td>
                  <form action="/motivofinsupervisions/<?php echo e($motivofinsupervision->id); ?>" method="POST">
                     <?php echo method_field('DELETE'); ?>
                     <?php echo csrf_field(); ?>
                     <div class="form-group">
                        <input type="hidden" name="url" class="form-control" id="" value=<?php echo e(URL::previous()); ?>>
                    </div>
                     <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                  </form>                     
               </td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
   </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('parameters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/motivofinsupervisions/index.blade.php ENDPATH**/ ?>