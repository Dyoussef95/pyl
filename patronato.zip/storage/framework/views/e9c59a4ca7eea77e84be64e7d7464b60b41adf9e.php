<?php $__env->startSection('title'); ?>
    Editar Historia <?php echo e($historia->nombre); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <form action="/historias/<?php echo e($historia->id); ?>" method="POST" role="form" id="form">
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>
        <legend>Editar historia</legend>

        <?php echo $__env->make('historias._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>
     
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/historias/edit.blade.php ENDPATH**/ ?>