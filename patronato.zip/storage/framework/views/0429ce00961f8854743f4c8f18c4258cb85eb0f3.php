<?php $__env->startSection('content'); ?>


    <!--Muestra mensajes de errores de validacion-->
    
    <h1>INGRESAR NUEVO ASISTIDO</h1>
    <h2>Nuevo N° legajo: <?php echo e($nuevoLegajo); ?></h2>
    <h3>Ingresar datos del tutelado/a:</h3>
    <form action="/ingreso-nuevo" method="POST" role="form" id="form">
        <?php echo csrf_field(); ?>
        
    
        <?php echo $__env->make('mesaentrada._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <button type="submit" class="btn btn-primary">Agregar</button>
    </form>

    
     
<?php $__env->stopSection(); ?> 


<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/mesaentrada/create.blade.php ENDPATH**/ ?>