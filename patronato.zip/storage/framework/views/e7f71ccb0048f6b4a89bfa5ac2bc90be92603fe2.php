<?php $__env->startSection('styles'); ?>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/jquery.dataTables.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('internos.import.excel')); ?>" method="post" enctype="multipart/form-data">
   <?php echo csrf_field(); ?>
   <?php if(Session::has('message')): ?>
      <p><?php echo e(Session::get('message')); ?></p>
   <?php endif; ?>
   

   <input type="file" name="file" id="file">

   <button class="btn btn-primary">Importar</button>
  
</form>

<button type="button" class="btn btn-primary" onclick="location.href='internos/create'">Agregar Nuevo</button>

<br><br>
<!--<input type="text" id="myInput" onkeyup="search()" placeholder="Buscar..">
<h4>Buscar por:</h4>
<input type="radio" name="selection" checked value="0"> Apellido
<input type="radio" name="selection" value="1"> Nombre
<input type="radio" name="selection" value="2"> N° Documento
<input type="radio" name="selection" value="3"> Localidad
<input type="radio" name="selection" value="4"> Trabajo
<input type="radio" name="selection" value="5"> Legajo
<div>Cantidad:<b id="cant"></b></div>-->
<div class="table-responsive">
   <table id="dataTable" name="dataTable" class="table table-hover">
      <thead class="thead-dark">
         <tr>
            <th>Apellido</th>
            <th scope="col">Nombres</th>
            <th scope="col">Numero de documento</th>
            <th scope="col">N° de legajo <!--<i onclick="sortTable(5)" style="cursor: pointer;" class="fas fa-sort">--></i>
            </th>
            <th scope="col"></th>
            <th scope="col"></th>
         </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $internos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr onclick="location.href='/internos/<?php echo e($interno->id); ?>'" style="cursor: pointer;">
            <td onclick="location.href='/internos/<?php echo e($interno->id); ?>'"><?php echo $interno->apellido; ?></td>
            <td><?php echo $interno->nombre; ?></td>
            <td><?php echo $interno->numero_documento; ?></td>
            <td><?php echo $interno->legajo; ?></td>
            <td>
            <?php if($interno->historia()->first()->empleado()->first()->id==Auth::user()->empleado->id): ?>
               <a href="internos/<?php echo e($interno->id); ?>/edit" class="btn btn-success btn-sm m-0">Editar</a>
            <?php endif; ?>
            </td>
            <td>
               <form action="/internos/<?php echo e($interno->id); ?>" method="POST">
                  <?php echo method_field('DELETE'); ?>
                  <?php echo csrf_field(); ?>
                  <div class="form-group">
                     <input type="hidden" name="url" class="form-control" id="" value=<?php echo e(URL::current()); ?>>
                  </div>
                  <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
               </form>
            </td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
   </table>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script src="<?php echo e(asset('js/jquery.dataTables.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/internos/index.blade.php ENDPATH**/ ?>