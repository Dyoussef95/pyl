<?php echo csrf_field(); ?>

<div class="form-group">
    <label for="">Nombre</label>
<input type="text" name="nombre" value="<?php echo e(isset($area) ? $area->nombre : ''); ?>" class="form-control" id="" placeholder="Ingrese un nombre">
</div>

<?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/areas/_form.blade.php ENDPATH**/ ?>