<?php $__env->startSection('parametersContent'); ?>
    
   <h1>Lugar de Tratamiento de Consumo</h1>

   <button type="button" class="btn btn-info" onclick="location.href='lugartratamientoconsumos/create'">Agregar Nuevo</button>
   <br><br>
   <div class="table-responsive-sm">
   <table class="table table-striped" id="tabla" style="width:auto">
      <thead class="thead-dark">
         <tr>
            <th scope="col">Nombre</th>
            <th scope="col">Direccion</th>
            <th scope="col"></th>
            <th scope="col"></th>
         </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $lugartratamientoconsumos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lugartratamientoconsumo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <td><?php echo $lugartratamientoconsumo->nombre; ?></td>
               <td><?php echo $lugartratamientoconsumo->direccion; ?></td>
               <td>
                  <a href="lugartratamientoconsumos/<?php echo e($lugartratamientoconsumo->id); ?>/edit" class="btn btn-success btn-sm">Editar</a>
               </td>
               <td>
                  <form action="/lugartratamientoconsumos/<?php echo e($lugartratamientoconsumo->id); ?>" method="POST">
                     <?php echo method_field('DELETE'); ?>
                     <?php echo csrf_field(); ?>
                     <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                  </form>                     
               </td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
   </table>
   </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('parameters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/lugartratamientoconsumos/index.blade.php ENDPATH**/ ?>