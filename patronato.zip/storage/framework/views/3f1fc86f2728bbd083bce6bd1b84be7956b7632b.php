<?php $__env->startSection('title'); ?>
    Editar Asistido <?php echo e($interno->nombre); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <form action="/internos/<?php echo e($interno->id); ?>" method="POST" id="form" role="form">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <legend>Editar asistido</legend>

        <?php echo $__env->make('internos._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>
     
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/js/select2.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/internos/edit.blade.php ENDPATH**/ ?>