<?php echo csrf_field(); ?>

<div class="form-group">
    <label for="">Nombre</label>
<input type="text" name="nombre" value="<?php echo e(isset($regiman) ? $regiman->nombre : ''); ?>" class="form-control" id="" placeholder="Ingrese un nombre">
</div>

<div class="form-group">
    <select name="area_id" form="form" class="select2" style="width:400px;">
        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value=<?php echo e($area->id); ?>

                <?php if(isset($regiman)): ?>
                    <?php echo e($regiman->area->id==$area->id ? 'selected' : ''); ?>

                <?php endif; ?>
            >
            <?php echo e($area->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>


<div class="form-group">
    <input type="hidden" name="url" class="form-control" id="" value=<?php echo e(URL::previous()); ?>>
</div><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/regimenes/_form.blade.php ENDPATH**/ ?>