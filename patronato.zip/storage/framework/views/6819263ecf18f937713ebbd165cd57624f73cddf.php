<?php $__env->startSection('content'); ?>
    
    <form action=<?php echo e(route('gruposfamiliares.store', ['interno' => $interno])); ?> method="POST" role="form" id="form">
        <legend>Agregar miembro al grupo familiar de: <?php echo $interno->nombre; ?> <?php echo $interno->apellido; ?></legend>
    
        <?php echo $__env->make('GruposFamiliares._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
        <button type="submit" class="btn btn-primary">Agregar</button>
    </form>
     
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/GruposFamiliares/create.blade.php ENDPATH**/ ?>