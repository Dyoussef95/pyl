<?php $__env->startSection('title'); ?>
    Editar parentezco <?php echo e($parentezco->nombre); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <form action="/parentezcos/<?php echo e($parentezco->id); ?>" method="POST" role="form">
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>
        <legend>Editar parentezco</legend>

        <?php echo $__env->make('parentezcos._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>
     
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/parentezcos/edit.blade.php ENDPATH**/ ?>