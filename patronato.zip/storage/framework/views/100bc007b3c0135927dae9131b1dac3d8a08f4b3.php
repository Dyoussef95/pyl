<?php $__env->startSection('content'); ?>


<h1>Usuarios</h1>



<button type="button" class="btn btn-primary" onclick="location.href='usuarios/create'">Agregar Nuevo</button>
<br><br>
<div class="table-responsive">
   <table class="table table-striped" id="tabla" style="width:auto">
      <thead class="thead-dark">
         <tr>
            <th scope="col">Nombre</th>
            <th scope="col">Apellido</th>
            <th scope="col">Usuario</th>
            <th scope="col">Email</th>
            <th scope="col"></th>
            <th scope="col"></th>
         </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo $empleado->nombre; ?></td>
            <td><?php echo $empleado->apellido; ?></td>
            <td><?php echo $usuarios->find($empleado->user_id)->name; ?></td>
            <td><?php echo $usuarios->find($empleado->user_id)->email; ?></td>
            <td>
               <a href="usuarios/<?php echo e($empleado->user_id); ?>/edit" class="btn btn-success btn-sm">Editar</a>
            </td>
            <td>
               <form action="/usuarios/<?php echo e($empleado->user_id); ?>" method="POST">
                  <?php echo method_field('DELETE'); ?>
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
               </form>
            </td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
   </table>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/usuarios/index.blade.php ENDPATH**/ ?>