<?php $__env->startSection('content'); ?>
    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <form action="/situacionsalud/enfermedad/<?php echo e($situacionSalud->id); ?>" method="POST" role="form" id="form">
        <legend>Agregar nueva Enfermedad</legend>
    
        <?php echo $__env->make('situacionsaluds._formEnfermedad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <button type="submit" class="btn btn-primary">Agregar</button>
    </form>
     
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('Index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/situacionsaluds/createEnfermedad.blade.php ENDPATH**/ ?>