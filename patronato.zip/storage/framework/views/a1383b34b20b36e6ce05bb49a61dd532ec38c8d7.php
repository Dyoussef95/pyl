<?php echo csrf_field(); ?>

<div class="form-group">
    <label for="">Consumo</label>
    <select name="consumo_id" form="form" class="select2" style="width:400px;">
        <?php $__currentLoopData = $listaConsumos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listaConsumo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value=<?php echo e($listaConsumo->id); ?>            
            <?php if(isset($situacionSaludConsumo/*SI EL CONSUMO EXISTE APARECERA SELECCIONADO*/)): ?>
                <?php echo e($listaConsumo->id==$situacionSaludConsumo->consumo_id ? 'selected' : ''); ?> 
            <?php endif; ?>>
            <?php echo e($listaConsumo->objeto_consumo); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <label for="">Tipo de Consumo</label>
    <select name="tipo_consumo_id" form="form" class="select2" style="width:400px;">
        <?php $__currentLoopData = $tiposConsumo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoConsumo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value=<?php echo e($tipoConsumo->id); ?>            
            <?php if(isset($situacionSaludConsumo/*SI EL CONSUMO EXISTE APARECERA SELECCIONADO*/)): ?>
                <?php echo e($tipoConsumo->id==$situacionSaludConsumo->tipo_consumo_id ? 'selected' : ''); ?> 
            <?php endif; ?>>
            <?php echo e($tipoConsumo->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group" onclick="ocultarLugar();">
    <label for="">Recibe tratamiento?</label>
    <br>
    <input type="radio" name="tratamiento" value="false" checked> 
    No
    <br>
    <input id="radioTrue" type="radio" name="tratamiento" value="true" 
    <?php if(isset($situacionSaludConsumo)): ?>
        <?php echo e($situacionSaludConsumo->tratamiento==true ? 'checked' : ''); ?> 
    <?php endif; ?>> 
    Si
    <br>
</div>

<div id="form_lugar_tratamiento" style=
<?php if(isset($situacionSaludConsumo)): ?> 
    <?php echo e($situacionSaludConsumo->tratamiento==false ? "display:none" : "display:block"); ?>

<?php else: ?>
<?php echo e("display:none"); ?> 
<?php endif; ?>>

    <div class="form-group">

        <label for="">Lugar de Tratamiento del Consumo</label>
        <select name="lugar_tratamiento_consumo_id" form="form" class="select2" style="width:400px;">
            <?php $__currentLoopData = $centrosConsumo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centroConsumo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value=<?php echo e($centroConsumo->id); ?> 
                <?php if(isset($situacionSaludConsumo)): ?>
                    <?php echo e($centroConsumo->id == $situacionSaludConsumo->lugar_tratamiento_consumo_id ? 'selected' : ''); ?> 
                <?php endif; ?>>
                <?php echo e($centroConsumo->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group">
        <label for="">Tipo de Tratamiento del Consumo</label>
        <select name="tipo_tratamiento_consumos_id" form="form" class="select2" style="width:400px;">
            <?php $__currentLoopData = $tiposTratamientosConsumo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoTratamientoConsumo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value=<?php echo e($tipoTratamientoConsumo->id); ?> 
                <?php if(isset($situacionSaludConsumo)): ?>
                    <?php echo e($tipoTratamientoConsumo->id == $situacionSaludConsumo->tipo_tratamiento_consumos_id ? 'selected' : ''); ?> 
                <?php endif; ?>>
                <?php echo e($tipoTratamientoConsumo->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

</div>

<div class="form-group">
    <input type="hidden" name="url" class="form-control" id="" value=<?php echo e(URL::previous()); ?>>
</div>

<script>
    function ocultarLugar(){
        var x = document.getElementById("form_lugar_tratamiento");
        var y = document.getElementById("radioTrue");
        if (y.checked == true) {
            x.style.display = "block";
        } else {
            x.style.display = "none";
        }
    }
</script><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/situacionsaluds/_formConsumo.blade.php ENDPATH**/ ?>