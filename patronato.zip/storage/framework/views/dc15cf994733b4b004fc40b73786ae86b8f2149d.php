<?php $__env->startSection('content'); ?>


    
    <legend>EDITAR ASISTIDO <?php echo e($historia->interno->nombre); ?> <?php echo e($historia->interno->apellido); ?></legend>
    <legend>Datos del tutelado/a:</legend>
    <form action="/historias/<?php echo e($historia->id); ?>" method="POST" role="form" id="form">
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>
        
        <?php echo $__env->make('mesaentrada._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        
        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>

    
     
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/mesaentrada/edit.blade.php ENDPATH**/ ?>