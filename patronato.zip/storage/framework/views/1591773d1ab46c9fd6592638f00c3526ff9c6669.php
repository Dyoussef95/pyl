<div class="form-group">
    <label for="">Nombre</label>
<input type="text" name="nombre" value="<?php echo e(isset($delitoespecifico) ? $delitoespecifico->nombre : ''); ?>" class="form-control" id="" placeholder="Ingrese un nombre">
</div>

<div class="form-group">
    <select name="tipos_delitos_id" form="form" class="select2" style="width:400px;">
        <?php if(isset($tipodelitos)): ?>
            <?php $__currentLoopData = $tipodelitos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipodelito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($tipodelito->id); ?>><?php echo e($tipodelito->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<div class="form-group">
    <input type="hidden" name="habilitado" class="form-control" id="" value="true">
</div><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/delitoespecificos/_form.blade.php ENDPATH**/ ?>