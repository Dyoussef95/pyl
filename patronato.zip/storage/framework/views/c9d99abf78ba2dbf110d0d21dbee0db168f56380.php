<div class="form-group">
    <label for="">Nombre</label>
<input type="text" name="nombre" value="<?php echo e(isset($juzgadoespecifico) ? $juzgadoespecifico->nombre : ''); ?>" class="form-control" id="" placeholder="Ingrese un nombre">
</div>

<div class="form-group">
    <select name="juzgadoTipo_id" form="form" class="select2" style="width:400px;">
        <?php if(isset($juzgadostipos)): ?>
            <?php $__currentLoopData = $juzgadostipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juzgadotipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($juzgadotipo->id); ?>><?php echo e($juzgadotipo->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<div class="form-group">
    <input type="hidden" name="habilitado" class="form-control" id="" value="true">
</div>

<?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/juzgadosespecificos/_form.blade.php ENDPATH**/ ?>