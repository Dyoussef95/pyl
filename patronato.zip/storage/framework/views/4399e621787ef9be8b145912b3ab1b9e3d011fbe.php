<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/jquery.dataTables.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <h1>Mesa de Entrada</h1> 

    <div class="table-responsive">
    <table id="dataTableMesaEntrada" name="dataTableMesaEntrada" class="table table-hover">
      <thead class="thead-dark">
         <tr>
            <th>Legajo</th>  
            <th>Apellidos</th>
            <th>Nombres</th>
            <th>Profesional</th>
            <th scope="col"></th>
            <th scope="col"></th>
         </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $internos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo $interno->legajo; ?></td>
            <td><?php echo $interno->apellido; ?></td>
            <td><?php echo $interno->nombre; ?></td>
         
            <td><?php echo $interno->historia()->first()->empleado()->first()->apellido; ?> <?php echo $interno->historia()->first()->empleado()->first()->nombre; ?></td>
            
            <td>
               <a href="mesa-entrada/<?php echo e($interno->historia()->first()->id); ?>/edit" class="btn btn-success btn-sm m-0">Editar</a>
            </td>
            
            <td>                        
            <form action="/mesa-entrada/<?php echo e($interno->id); ?>" method="POST">
                  <?php echo method_field('DELETE'); ?>
                  <?php echo csrf_field(); ?>
                  
                  <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                  
                  <div class="form-group">
                     <input type="hidden" name="url" class="form-control" id="" value=<?php echo e(URL::current()); ?>>
                  </div>
               </form>
            </td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
   </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/jquery.dataTables.js')); ?>" defer></script>

<script src="<?php echo e(asset('js/mesaEntrada.js')); ?>" defer></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/mesaentrada/index.blade.php ENDPATH**/ ?>