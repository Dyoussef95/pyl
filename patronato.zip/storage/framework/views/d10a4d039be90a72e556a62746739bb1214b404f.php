<?php echo csrf_field(); ?>
<div class="form-group">
    <label for="">Nombre</label>
<input type="text" name="nombre" value="<?php echo e(isset($trabajo) ? $trabajo->nombre : ''); ?>" class="form-control" id="" placeholder="Ingrese un nombre">
</div>

<div class="form-group">
    <input type="hidden" name="url" class="form-control" id="" value=<?php echo e(URL::previous()); ?>>
</div>




<?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/trabajos/_form.blade.php ENDPATH**/ ?>