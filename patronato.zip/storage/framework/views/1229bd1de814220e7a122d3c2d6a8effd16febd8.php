<?php echo csrf_field(); ?>

<div class="form-group">
    <label for="">Nombre</label>
<input type="text" name="nombre" value="<?php echo e(isset($situacionlaboral) ? $situacionlaboral->nombre : ''); ?>" class="form-control" id="" placeholder="Ingrese un nombre">
</div>

<div class="form-group">
    <input type="hidden" name="habilitado" class="form-control" id="" value="true">
</div><?php /**PATH C:\Users\alumno\Patronato\patronato\resources\views/situacioneslaborales/_form.blade.php ENDPATH**/ ?>