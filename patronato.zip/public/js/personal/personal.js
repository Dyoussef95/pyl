window.onload = function() {
    var elem = document.getElementById('personal');
    elem.style.borderLeft = "4px solid #3498db";
    $(elem).parent().toggleClass('active2');
};


