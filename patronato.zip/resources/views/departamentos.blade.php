@foreach($departamentos as $departamento)

		<div style="margin: 0 0 20px">

			<div>
				{!! $departamento->nombre !!}
			</div>

		</div>

@endforeach