@extends('index')
@section('content')
    <img src="img/logo2.png" style="display: block;margin-left: auto;margin-right: auto;" alt="">
@endsection